<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2019/3/6
 * Time: 22:40
 */

return [
    'app_key' => env('ESHANGHU_APP_KEY', ''),
    'app_secret' => env('ESHANGHU_APP_SECRET', ''),
    'sub_mch_id' => env('ESHANGHU_SUB_MCH_ID', ''),
    'notify' => env('ESHANGHU_NOTIFY_URL', ''),
];