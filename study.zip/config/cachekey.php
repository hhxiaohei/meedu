<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2019/2/21
 * Time: 20:48
 */

return [
    'order' => [
        'wechat_remote_order' => [
            'name' => 'wechat_remote_order_%s',
            'expire' => 110,
        ],
    ],
];