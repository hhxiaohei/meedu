<?php
/**
 * Created by PhpStorm.
 * User: xiaoteng
 * Date: 2019/2/28
 * Time: 19:27
 */

return [
    'vod' => [
        'secret_id'  => '',
        'secret_key' => '',
    ],
];